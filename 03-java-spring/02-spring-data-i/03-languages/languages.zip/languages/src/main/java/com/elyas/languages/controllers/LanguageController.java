package com.elyas.languages.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import com.elyas.languages.models.Language;
import com.elyas.languages.services.LanguageService;

@Controller
public class LanguageController {
	private final LanguageService lService;
	public LanguageController(LanguageService service) {
		this.lService=service;
	}
	
	@GetMapping("/")
	public String index(Model model, @ModelAttribute("language") Language language) {
		model.addAttribute("allLanguage", this.lService.allLanguages());
		return "index.jsp";
	}
	
	@POSTMapping("/")
	public String addLanguage@Valid @ModelAttribute("language") Language language, BindingResualt result, Model model){
		if(result.hasErrors()) {
			model.addAttribute("allLanguage", this.lService.allLanguages());
			return "index.jsp";

		}
		
		this.lService.createLanguage(language);
		return "redirect:/";
	}
	
	@GetMapping("/show/{id}")
	public String showLang(Model model, @PathVariable("id") Long id) {
		model.addAttribute("thisLang", this.lService.findLanguage(id));
		return "show.jsp";
		
	}
	
	@GetMapping("/edit/{id}")
	public String editLnag(Model model, @PathVariable("id") Long id) {
		model.addAttribute("thisLang", this.lService.findLanguage(id));
		return "edit.jsp";
		}
	
	@PutMapping("/edit/{id}")
	public String editLang(@Valid, @ModelAttribute("language") Language lang, BindingResualt result, Model model, @PathVariable("id") Long id) {
		if(result.hasErrors()) {
		model.addAttribute("thisLang", this.lService.findLanguage(id));
		return "edit.jsp";
		}
		this.lService.updateLanguage(lang);
		
		return "redirect:/show/{id}";
	}
	
	@DeleteMapping("/delete/{id}")
	public String deleteLang(@PathVariable("id") Long id) {
		this.lService.deleteLanguage(id);
		return "redirect:/";
	}

}
