package com.elyas.languages.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.elyas.languages.models.Language;
import com.elyas.languages.repositories.LanguageRepository;

@Service

public class LanguageService {
	private final LanguageRepository lRepo;
	
	public LanguageService(LanguageRepository repo) {
		this.lRepo = repo;
	}
	
	//find all languages 
	public List<Language> allLanguages(){
		return this.lRepo.findAll();
	}
	
	//find one language
	
	public Language findLanguage(Long id) {
		return this.lRepo.findById(id).orElse(null);
	}
	
	//create
	public Language createLanguage(Language newLang) {
		return this.lRepo.save(newLang);
	}
	
	//update
	public Language updateLanguage(Language updatedLang) {
		return this.lRepo.save(updatedLang);
		
	}
	
	//delete
	public void deleteLanguage(Long id) {
		this.lRepo.deleteById(id);
	}

}
