package com.elyas.dojosurvey.controllers;

import com.elyas.survey.modles.Survey;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class SurveyController {
	@RequestMapping("/")
	public String index(Model viewModel) {
		viewModel.addAttribute("location", new String[] {"Seattle", "Vancouver", "Burnaby", "SanDiego"});
		viewModel.addAttribute("language", new String[] {"Java", "JavaScript", "Python",});
		return "index.jsp";
	}
	
	@RequestMapping(value="/survey", method=RequestMethod.POST)
	public String survey(@RequestParam("name") String name, @RequestParam("location") String location, @RequestParam("language") String language, @RequestParam("comment") String comment,   {
		/*viewModel.addAttribute("name",name);
		viewModel.addAttribute("location",location);
		viewModel.addAttribute("language",language);
		viewModel.addAttribute("comment",comment);
		replaced by models package and lines belew*/
		
		viewModel.addAttribute("result",new Survay(name,location,language,comment));
		return "result.jsp";
	}

}
