function dateAlet() {
	alert(`The date page was loaded`);
}

function timeAlet() {
	alert(`The time page was loaded`);
}